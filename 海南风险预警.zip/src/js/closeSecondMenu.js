$(function () {
  $('body').on('click',function() {
    $(top.window.document).find('.second-menu').hide()
  })
})